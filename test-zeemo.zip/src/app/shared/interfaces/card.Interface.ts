export interface ICard {
    value: string,
    image: string
}